import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Plataforma plataforma = new Plataforma();

        int opcao;

        do {
            System.out.println("\n=== Sonora ===");
            System.out.println("1 - Cadastrar música manualmente");
            System.out.println("2 - Cadastrar usuário");
            System.out.println("3 - Criar playlist e adicionar músicas");
            System.out.println("4 - Buscar música por id");
            System.out.println("5 - Buscar música por título");
            System.out.println("6 - Reproduzir uma música");
            System.out.println("7 - Listar acervo");
            System.out.println("8 - Seguir usuário");
            System.out.println("9 - Deixar de seguir usuário");
            System.out.println("10 - Listar usuários seguidos");
            System.out.println("0 - Sair");
            System.out.print("Escolha uma opção: ");

            try {
                opcao = Integer.parseInt(scanner.nextLine());
            } catch (NumberFormatException e) {
                System.out.println("Digite uma opção válida.");
                opcao = -1;
                continue;
            }

            switch (opcao) {

                case 1:
                    try {
                        System.out.print("Título: ");
                        String titulo = scanner.nextLine();

                        System.out.print("Artista: ");
                        String artista = scanner.nextLine();

                        System.out.print("Álbum: ");
                        String album = scanner.nextLine();

                        System.out.print("Duração em segundos: ");
                        int duracao = Integer.parseInt(scanner.nextLine());

                        Musica musica = new Musica(
                                titulo,
                                duracao,
                                artista,
                                album
                        );

                        if (plataforma.cadastrarMusica(musica)) {
                            System.out.println("Música cadastrada.");
                            System.out.println("ID: " + musica.getId());
                        } else {
                            System.out.println("Não foi possível cadastrar a música.");
                        }

                    } catch (NumberFormatException e) {
                        System.out.println("A duração precisa ser um número.");

                    } catch (IllegalArgumentException e) {
                        System.out.println(
                                "Não foi possível cadastrar: "
                                + e.getMessage());

                    } finally {
                        System.out.println("Operação finalizada.");
                    }

                    break;

                case 2:
                    try {
                        System.out.print("Nome: ");
                        String nome = scanner.nextLine();

                        System.out.print("Email: ");
                        String email = scanner.nextLine();

                        Usuario usuario = new Usuario(nome, email);

                        if (plataforma.cadastrarUsuario(usuario)) {
                            System.out.println("Usuário cadastrado.");
                            System.out.println("ID: " + usuario.getId());
                        } else {
                            System.out.println("Não foi possível cadastrar o usuário.");
                        }

                    } catch (IllegalArgumentException e) {
                        System.out.println(
                                "Não foi possível cadastrar: "
                                + e.getMessage());
                    }

                    break;

                case 3:
                    try {
                        System.out.print("Nome da playlist: ");
                        String nomePlaylist = scanner.nextLine();

                        System.out.print("ID do usuário dono: ");
                        int idUsuario = Integer.parseInt(scanner.nextLine());

                        Usuario dono = plataforma.buscarUsuarioPorId(idUsuario);

                        if (dono == null) {
                            System.out.println("Usuário não encontrado.");
                            break;
                        }

                        Playlist playlist = new Playlist(nomePlaylist, dono);

                        int opcaoPlaylist;

                        do {
                            System.out.println("\n=== Playlist: "
                                    + playlist.getNome() + " ===");
                            System.out.println("1 - Adicionar música");
                            System.out.println("2 - Remover música");
                            System.out.println("3 - Mostrar quantidade");
                            System.out.println("4 - Mostrar duração total");
                            System.out.println("5 - Reproduzir tudo");
                            System.out.println("0 - Voltar");
                            System.out.print("Escolha uma opção: ");

                            try {
                                opcaoPlaylist =
                                        Integer.parseInt(scanner.nextLine());

                            } catch (NumberFormatException e) {
                                System.out.println(
                                        "Digite uma opção válida.");
                                opcaoPlaylist = -1;
                                continue;
                            }

                            switch (opcaoPlaylist) {

                                case 1:
                                    try {
                                        System.out.print("ID da música: ");
                                        int idMusica =
                                                Integer.parseInt(scanner.nextLine());

                                        Musica musicaPlaylist =
                                                plataforma.buscarMusicaPorId(idMusica);

                                        if (musicaPlaylist == null) {
                                            System.out.println(
                                                    "Música não encontrada.");

                                        } else if (playlist.adicionar(musicaPlaylist)) {
                                            System.out.println(
                                                    "Música adicionada.");
                                        }

                                    } catch (NumberFormatException e) {
                                        System.out.println(
                                                "O ID precisa ser um número.");

                                    } catch (IllegalArgumentException e) {
                                        System.out.println(
                                                "Não foi possível adicionar: "
                                                + e.getMessage());
                                    }

                                    break;

                                case 2:
                                    try {
                                        System.out.print("Posição da música: ");
                                        int indice =
                                                Integer.parseInt(scanner.nextLine());

                                        playlist.removerNaPosicao(indice);

                                        System.out.println("Música removida.");

                                    } catch (NumberFormatException e) {
                                        System.out.println(
                                                "A posição precisa ser um número.");

                                    } catch (IndexOutOfBoundsException e) {
                                        System.out.println(
                                                "Essa posição não existe "
                                                + "na playlist.");
                                    }

                                    break;

                                case 3:
                                    System.out.println("Quantidade: "
                                            + playlist.getQuantidade());
                                    break;

                                case 4:
                                    System.out.println("Duração total: "
                                            + playlist.getDuracaoTotalSegundos()
                                            + " segundos");
                                    break;

                                case 5:
                                    playlist.reproduzirTudo();
                                    System.out.println(
                                            "Todas as músicas foram reproduzidas.");
                                    break;

                                case 0:
                                    break;

                                default:
                                    System.out.println("Opção inválida.");
                            }

                        } while (opcaoPlaylist != 0);

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "O ID do usuário precisa ser um número.");

                    } catch (IllegalArgumentException e) {
                        System.out.println(
                                "Não foi possível criar a playlist: "
                                + e.getMessage());
                    }

                    break;

                case 4:
                    try {
                        System.out.print("ID da música: ");
                        int id = Integer.parseInt(scanner.nextLine());

                        Musica musicaId =
                                plataforma.buscarMusicaPorId(id);

                        if (musicaId != null) {
                            System.out.println("ID: " + musicaId.getId());
                            System.out.println("Título: " + musicaId.getTitulo());
                            System.out.println("Artista: " + musicaId.getArtista());
                            System.out.println("Duração: "
                                    + musicaId.getDuracaoFormatada());
                            System.out.println("Reproduções: "
                                    + musicaId.getReproducoes());
                        } else {
                            System.out.println("Música não encontrada.");
                        }

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "O ID precisa ser um número.");
                    }

                    break;

                case 5:
                    System.out.print("Título da música: ");
                    String tituloBusca = scanner.nextLine();

                    Musica musicaTitulo =
                            plataforma.buscarMusica(tituloBusca);

                    if (musicaTitulo != null) {
                        System.out.println("ID: " + musicaTitulo.getId());
                        System.out.println("Título: " + musicaTitulo.getTitulo());
                        System.out.println("Artista: " + musicaTitulo.getArtista());
                        System.out.println("Duração: "
                                + musicaTitulo.getDuracaoFormatada());
                    } else {
                        System.out.println("Música não encontrada.");
                    }

                    break;

                case 6:
                    try {
                        System.out.print("ID da música: ");
                        int idReproducao =
                                Integer.parseInt(scanner.nextLine());

                        Musica musicaReproducao =
                                plataforma.buscarMusicaPorId(idReproducao);

                        if (musicaReproducao != null) {
                            musicaReproducao.reproduzir();

                            System.out.println("Música reproduzida.");
                            System.out.println("Reproduções: "
                                    + musicaReproducao.getReproducoes());
                        } else {
                            System.out.println("Música não encontrada.");
                        }

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "O ID precisa ser um número.");
                    }

                    break;

                case 7:
                    System.out.println("\n=== Acervo ===");

                    for (int i = 1;
                         i <= plataforma.getTotalMusicas();
                         i++) {

                        Musica musicaAcervo =
                                plataforma.buscarMusicaPorId(i);

                        if (musicaAcervo != null) {
                            System.out.println(
                                    musicaAcervo.getId()
                                    + " - "
                                    + musicaAcervo.getTitulo()
                                    + " - "
                                    + musicaAcervo.getArtista()
                                    + " - "
                                    + musicaAcervo.getDuracaoFormatada()
                            );
                        }
                    }

                    break;

                case 8:
                    try {
                        System.out.print("ID do usuário que vai seguir: ");
                        int idUsuario =
                                Integer.parseInt(scanner.nextLine());

                        System.out.print("ID do usuário que será seguido: ");
                        int idOutro =
                                Integer.parseInt(scanner.nextLine());

                        Usuario usuario =
                                plataforma.buscarUsuarioPorId(idUsuario);

                        Usuario outro =
                                plataforma.buscarUsuarioPorId(idOutro);

                        if (usuario == null || outro == null) {
                            System.out.println("Usuário não encontrado.");
                            break;
                        }

                        if (usuario.seguir(outro)) {
                            System.out.println("Usuário seguido.");
                        } else {
                            System.out.println(
                                    "Não foi possível seguir o usuário.");
                        }

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "O ID precisa ser um número.");

                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }

                    break;

                case 9:
                    try {
                        System.out.print("ID do usuário: ");
                        int idUsuario =
                                Integer.parseInt(scanner.nextLine());

                        System.out.print(
                                "ID do usuário que deseja deixar de seguir: ");
                        int idOutro =
                                Integer.parseInt(scanner.nextLine());

                        Usuario usuario =
                                plataforma.buscarUsuarioPorId(idUsuario);

                        Usuario outro =
                                plataforma.buscarUsuarioPorId(idOutro);

                        if (usuario == null || outro == null) {
                            System.out.println("Usuário não encontrado.");
                            break;
                        }

                        if (usuario.deixarDeSeguir(outro)) {
                            System.out.println(
                                    "Deixou de seguir o usuário.");
                        } else {
                            System.out.println(
                                    "O usuário não estava sendo seguido.");
                        }

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "O ID precisa ser um número.");

                    } catch (IllegalArgumentException e) {
                        System.out.println(e.getMessage());
                    }

                    break;

                case 10:
                    try {
                        System.out.print("ID do usuário: ");
                        int idUsuario =
                                Integer.parseInt(scanner.nextLine());

                        Usuario usuario =
                                plataforma.buscarUsuarioPorId(idUsuario);

                        if (usuario == null) {
                            System.out.println("Usuário não encontrado.");
                            break;
                        }

                        for (int i = 0;
                             i < usuario.getQuantidadeSeguindo();
                             i++) {

                            Usuario seguido =
                                    usuario.getSeguindoNaPosicao(i);

                            System.out.println(
                                    seguido.getId()
                                    + " - "
                                    + seguido.getNome()
                                    + " - "
                                    + seguido.getEmail()
                            );
                        }

                    } catch (NumberFormatException e) {
                        System.out.println(
                                "O ID precisa ser um número.");
                    }

                    break;

                case 0:
                    System.out.println("Saindo...");
                    break;

                default:
                    System.out.println("Opção inválida.");
            }

        } while (opcao != 0);

        try {
            Musica musica1 = new Musica(
                    "Master of Puppets",
                    355,
                    "Metallica",
                    "Master of Puppets"
            );

            Musica musica2 = new Musica(
                    "Somewhere I Belong",
                    183,
                    "Linkin Park",
                    "Meteora"
            );

            Podcast podcast = new Podcast(
                    "Podcast Sonora",
                    3600,
                    "Apresentador",
                    1
            );

            musica1.reproduzir();
            musica2.reproduzir();
            podcast.reproduzir();

            System.out.println(musica1);
            System.out.println(musica2);
            System.out.println(podcast);

        } catch (IllegalArgumentException e) {
            System.out.println(
                    "Não foi possível demonstrar a herança: "
                    + e.getMessage());
        }

        scanner.close();
    }
}